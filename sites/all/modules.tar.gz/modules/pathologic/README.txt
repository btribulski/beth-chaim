Pathologic
----------

Project Page:
http://drupal.org/project/pathologic

By Garrett Albright
http://drupal.org/user/191212
Email: albright (at) anre [dot] net
AIM: AlbrightGuy - ICQ: 150670553 - IRC: Albright

Installation & Configuration
----------------------------

For full installation and configuration instructions, please see this page in the Drupal manual:
http://drupal.org/node/257026