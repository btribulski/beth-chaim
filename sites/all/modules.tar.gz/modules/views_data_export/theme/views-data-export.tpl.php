<?php print $header ?>
<?php print $body ?>
<?php print $footer ?>