To build your own Panels layout follow the documentation provided by Panels:
  http://drupal.org/node/495654
